from django.urls import path
from core.views import *


urlpatterns = [
    path("",index,name="home"),
    path("objectcal/",objectcal,name="measure"),
    path("objectcalcu/",objectcalcu,name="cal"),
    path("quality/",quality,name='quality'),
    path("anomaly/",anomaly,name="anomaly"),
    path("safety/",safety,name="safety"),
    path("newfront/",newfront,name="newfront"),
    path("object/",object,name="object")
]