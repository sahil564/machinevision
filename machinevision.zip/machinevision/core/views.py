from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request,"anomaly.html")

def objectcal(request):
    return render(request,"objectcal.html")

def objectcalcu(request):
    return render(request,"objectcalcu.html")

def quality(request):
    return render(request,"quality.html")

def anomaly(request):
    return render(request,"anomaly.html")


def safety(request):
    return render(request,"safaty.html")


def newfront(request):
    return render(request,"newfront.html")